#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#define TAM 40
#define VERSION "v01.00.00"
void leer_comandos(char *);

int main(void) {
	char *cadena;
	printf("** Shell Application v01.00.00 **\n");
	while(1){
		cadena = malloc(TAM*sizeof(char));
		leer_comandos(cadena);
		free(cadena);
	}
	return 0;
}

void leer_comandos(char *p){
	char *comando1="version";
	char *comando2="echo";
	char *comando3="reset";
	fgets(p, TAM, stdin);
	if(strncmp(p, comando1, strlen(comando1))==0){
		if(strlen(p)-1==strlen(comando1)){
			printf("%s\n", VERSION);
			printf("\n");
		}else{
			printf("FAIL\n"); 
		}
	}else{
		if(strncmp(p, comando2, strlen(comando2))==0){
			for(int i=4;i<=strlen(p);i++){ //comienza a leer en 4 por por "echo"
				printf("%c", p[i]);
			}
		}
	}	
		if(strncmp(p, comando3, strlen(comando3))==0){
			if(strlen(p)-1==strlen(comando3)){
				printf("OK");
				printf("\n");
			}else{
				printf("FAIL\n"); 
			}
		}
		
	
	printf("\n");
	
}


