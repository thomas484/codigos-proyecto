#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include "termset.h"
#include <string.h>



union sensores{
	float valor;
	unsigned char p[5];
	
};
struct infoUsuario {
	
	char nombre[20];
	char apellido[20];
	char cultivo[20];
	int estacion;
	
};

//declaracion de prototipos de funciones 
char menu1(void); 
void escribir_puerto(int *, const char *);
float leer_dato_float_arduino(int *, const char *, int);
void cargar_usuarios (struct infoUsuario *u);
void recomendacion_climatica(struct infoUsuario *, union sensores *);

int main(int argc, char *argv[]){
	
	int fd, estado=1, modo=1; //las variables etado y modo son utlizadas para controlar estados del programa
	struct termios oldtty, newtty; //crea datos de tipo estructura para la comunicacion
	union sensores sensor; //se crea un arreglo de uniones para guardar los datos de temperatura
	struct infoUsuario usuario; //se crea una estructura para cargar los usuarios 
	//lectura 
	system("clear");
	printf("\t\t\t\t\t\t\t\tSoftdin v1.0\n");
	
	if(argc != 2) { //acá se asegura que le pasaste el nombre del puertp
		printf("\t\t\t\t\tNo introdujo el nombre del puerto\n");
		exit(0);
	}
	fd = open(argv[1], O_RDWR | O_NOCTTY); //abre el puerto
	if(fd == -1){
		printf("\t\t\t\t\tERROR:  no se pudo abrir el dispositivo\n");
		return -1;
	}
	if(termset(fd, 9600, &oldtty, &newtty) == -1){
		printf("\t\t\t\t\tERROR: no se pudo configurar el tty\n");
		return -1;
	}
	tcflush(fd, TCIOFLUSH); //limpia el puerto 
	
	cargar_usuarios(&usuario);
	
	//////////////////MAIN///////////////////////////
	
	do{
		
		switch(menu1()){
			
		case 'm':
			char a;
			do{
				printf("\t\t\t\t\t\t\t         Modo manual.\n");
				printf("\t\t\t\t\t\t\tIngrese la tecla 'd' para desagote.\n");
				printf("\t\t\t\t\t\t\tIngrese la tecla 'k' para llenado.\n");
				printf("\t\t\t\t\t\t\tIngrese la tecla 's' para salir.\n");
				printf("\t\t\t\t\t\t\t       Opcion: ");
				scanf(" %c", &a);
				printf("\n");
				if(a == 'd'){
					escribir_puerto(&fd, "1");
				}
				if(a == 'k'){
					escribir_puerto(&fd, "2");
				}
				if(a == 's'){
					escribir_puerto(&fd, "3");
					modo=0;
				}
			}while(modo==1);
			modo=1;
			break;
			
		case 'a':
			char b;
			do{
				printf("\t\t\t\t\t\t\t          Modo ráfaga.\n");
				printf("\t\t\t\t\t\tIngrese la tecla '1' para setear circulacion moderada en 1 segundo.\n");
				printf("\t\t\t\t\t\tIngrese la tecla '2' para setear circulacion moderada en 2 segundos.\n");
				printf("\t\t\t\t\t\tIngrese la tecla '3' para setear circulacion moderada en 3 segundos.\n");
				printf("\t\t\t\t\t\tIngrese la tecla 's' para salir.\n");
				printf("\t\t\t\t\t\t        Opcion: ");
				scanf(" %c", &b);
				printf("\n");
				if(b == '1'){
					escribir_puerto(&fd, "5");
				}
				if(b == '2'){
					escribir_puerto(&fd, "6");
				}
				if(b == '3'){
					escribir_puerto(&fd, "7");
				}
				if(b == 's'){
					escribir_puerto(&fd, "3");
					modo=0;
				}
				
			}while(modo==1);
			modo=1;
			break;
			
		case 'l':
			sensor.valor=leer_dato_float_arduino(&fd, "4", 10);
			printf("\t\t\t\t\t\t\tPromedio de temperatura: %.2f °c\n", sensor.valor);
			sleep(2);
			recomendacion_climatica(&usuario, &sensor);
			sleep(3);
			system("clear");
			break;
			
		case 'f':
			printf("\t\t\t\t\t\t\tDatos del usuario: ");
			printf("\n");
			printf("\t\t\t\t\t\t\tNombre de usuario: %s.\n", usuario.nombre);
			printf("\t\t\t\t\t\t\tApellido de usuario: %s.\n", usuario.apellido);
			printf("\t\t\t\t\t\t\tVegetal: %s.\n", usuario.cultivo);
			printf("\t\t\t\t\t\t\tEstacion: ");
			switch(usuario.estacion){
			case 1:
				printf("Oto�o.\n");
				break;
			case 2:
				printf("Invierno.\n");
				break;
			case 3:
				printf("Primavera.\n");
				break;
			case 4:
				printf("Verano.\n");
				break;
			}
			sleep(5); //espera 10 segundos para leer toda la informacion
			system("clear");
			break;
		default:
			estado = 0;
			close(fd);//cierra el puerto 
		}
	}while(estado!=0); //termina el main con esa opcion sale del programa y se cierra el archivo
	system("clear");
	return 0;
}
	////////FUNCION DE MENU///////////////////////
	
	char menu1(void){
		char a;
		int s;
		printf("\t\t\t\t\t\t\t\tSoftdin v1.0\n");
		printf("\t\t\t\t\t\t\t       Menu de control.\n");
		printf("\t\t\t\t\t\tIngrese la tecla 'm' para modo manual.\n");
		printf("\t\t\t\t\t\tIngrese la tecla 'a' para modo rafaga.\n");
		printf("\t\t\t\t\t\tIngrese la tecla 'l' para leer la temperatura ambiente.\n");
		printf("\t\t\t\t\t\tIngrese la tecla 'f' para ver informacion del usuario.\n");
		printf("\t\t\t\t\t\tIngrese la tecla 's' para salir del programa.\n");
		printf("\t\t\t\t\t\tIngrese una opcion: ");
		do{
			scanf(" %c", &a);
			printf("\n");
			if(!(a=='m' || a=='a' || a=='l' || a=='s' || a=='f')){
				printf("\t\t\t\t\t\tIngrese una opcion valida: ");
				s=1;
			}
			else{
				s=0;
			}
		}while(s==1);
		system("clear");
		return a;
	}
		
		///////////////FUNCIONES PARA ESCRIBIR EL PUERTO//////////////////////////////
		void escribir_puerto(int *f, const char *cadena){
			write(*f, cadena, strlen(cadena)); //manda el dato por el puerto serie
			tcdrain(*f); //drena el puerto 
			sleep(1); //espera un segundo
			system("clear"); //limpia la pantalla
		}
			
			///////////////FUNCION LEE PUERTO////////////////////////////////////
			float leer_dato_float_arduino(int *f, const char *cadena, int muestras){
				float lecturas=0.00, promedio=0.00;
				union dato{ //crea una union para guardar el dato 
					float temp;
					unsigned char partes[5];
				};
				
				union dato d1; //crea una dato de tipo union
				for(int i=0;i<muestras;i++){ //for para hacer n muestras
					
					write(*f, cadena, strlen(cadena)); //manda el dato por el puerto serie para despues el arduino poder mandar la temperatura como una union 
					tcdrain(*f); //drena el puerto 
					sleep(1); //espera un tiempo 
					
					int n = read(*f, (void *)d1.partes, 4); 
					if (n>0) {//si recibió algun dato 
						printf("\t\t\t\t\t\t  Temperatura ambiente: %.2f �c\n", d1.temp);
						sleep(1);
					}
					lecturas+=d1.temp; //suma las lecturas cada 1 segundo 
				}
				promedio=lecturas/muestras;
				system("clear");
				return promedio;
			}
				void recomendacion_climatica(struct infoUsuario *u, union sensores *s){
					switch(u->estacion){
						
					case 1:
					case 2:
						if(s->valor<15){
							printf("\t\t\t\t\t\t\t Se recomienda proteger los cultivos del frio.\n");
							printf("\t\t\t\t\t\t\t Debido a las estaciones de otoño-invierno.\n");
						}
					case 3:
					case 4:
						if(s->valor>35){
							printf("\t\t\t\t\t\t\t Se recomienda proteger los cultivos del calor.\n");
							printf("\t\t\t\t\t\t\t Debido a las esatciones de primavera-verano.\n");
						}
						break;
					default:
						printf("\t\t\t\t\t\t\t Se recomienda mantener esta temperatura actual.\n");
						break;
					}
					
				}
					
					void cargar_usuarios (struct infoUsuario *u){
						int e, a=0;
						do{
							printf("\t\t\t\t\t\t\tIngrese su nombre de usuario: "); scanf(" %s", u->nombre);
							printf("\n");
							printf("\t\t\t\t\t\t\tIngrese su apellido de usuario: "); scanf(" %s", u->apellido);
							printf("\n");
							printf("\t\t\t\t\t\t\tIngrese el vegetal a cultivar: "); scanf(" %s", u->cultivo);
							printf("\n");
							printf("\t\t\t\t\t\t\tIngrese 1 se está en otoño: "); printf("\n");
							printf("\t\t\t\t\t\t\tIngrese 2 se está en invierno: "); printf("\n");
							printf("\t\t\t\t\t\t\tIngrese 3 se está en primavera: "); printf("\n");
							printf("\t\t\t\t\t\t\tIngrese 4 se está en en verano: ");
							scanf("%d", &e);
							u->estacion = e;
							printf("\n");
							printf("\t\t\t\t\t\t\tDatos ingresados: ");
							printf("\n");
							printf("\t\t\t\t\t\t\tNombre de usuario: %s.\n", u->nombre);
							printf("\t\t\t\t\t\t\tApellido de usuario: %s.\n", u->apellido);
							printf("\t\t\t\t\t\t\tVegetal: %s.\n", u->cultivo);
							printf("\t\t\t\t\t\t\tEstacion: ");
							switch(u->estacion){
							case 1:
								printf("Otoño.\n");
								break;
							case 2:
								printf("Invierno.\n");
								break;
							case 3:
								printf("Primavera.\n");
								break;
							case 4:
								printf("Verano.\n");
								break;
							}
							printf("\t\t\t\t\t\t\tDatos ingresados correctos ?. 1 si, 0 no: ");
							scanf("%d", &a);
						}while(a==0);
						system("clear");
					}
						
						
						
